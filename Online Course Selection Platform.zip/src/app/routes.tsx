import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { LoginPage } from "./components/LoginPage";
import { StudentDashboard } from "./components/StudentDashboard";
import { CourseListing } from "./components/CourseListing";
import { Timetable } from "./components/Timetable";
import { AdminDashboard } from "./components/AdminDashboard";
import { CourseForm } from "./components/CourseForm";
import { NotFound } from "./components/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: LoginPage },
      { path: "student/dashboard", Component: StudentDashboard },
      { path: "student/courses", Component: CourseListing },
      { path: "student/timetable", Component: Timetable },
      { path: "admin/dashboard", Component: AdminDashboard },
      { path: "admin/course/new", Component: CourseForm },
      { path: "admin/course/edit/:id", Component: CourseForm },
      { path: "*", Component: NotFound },
    ],
  },
]);