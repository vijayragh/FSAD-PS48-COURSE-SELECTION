import { Sidebar } from './Sidebar';
import { BookOpen, CreditCard, AlertTriangle, TrendingUp, Trash2 } from 'lucide-react';
import { useCourses } from '../context/CourseContext';
import { Link } from 'react-router';
import { toast } from 'sonner';

export function StudentDashboard() {
  const { selectedCourses, removeCourse } = useCourses();

  const totalCredits = selectedCourses.reduce((sum, course) => sum + course.credits, 0);
  const maxCredits = 20;
  const hasConflicts = false; // Would be calculated from actual conflict detection

  const stats = [
    {
      label: 'Courses Enrolled',
      value: selectedCourses.length,
      icon: BookOpen,
      color: 'bg-blue-50 text-blue-600',
      bgColor: 'bg-blue-600',
    },
    {
      label: 'Total Credits',
      value: `${totalCredits}/${maxCredits}`,
      icon: CreditCard,
      color: 'bg-green-50 text-green-600',
      bgColor: 'bg-green-600',
    },
    {
      label: 'Schedule Conflicts',
      value: hasConflicts ? 'Yes' : 'None',
      icon: AlertTriangle,
      color: hasConflicts ? 'bg-red-50 text-red-600' : 'bg-gray-50 text-gray-600',
      bgColor: hasConflicts ? 'bg-red-600' : 'bg-gray-600',
    },
    {
      label: 'Progress',
      value: `${Math.round((totalCredits / maxCredits) * 100)}%`,
      icon: TrendingUp,
      color: 'bg-purple-50 text-purple-600',
      bgColor: 'bg-purple-600',
    },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" />
      
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <h1 className="text-3xl text-gray-900 mb-2">Welcome Back, Student!</h1>
          <p className="text-gray-600">Here's an overview of your academic progress</p>
        </div>

        {/* Main Content */}
        <div className="p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-lg ${stat.color}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                  <h3 className="text-2xl text-gray-900 mb-1">{stat.value}</h3>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Credit Progress Bar */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 mb-8">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg text-gray-900">Credit Load Progress</h3>
              <span className="text-sm text-gray-600">
                {totalCredits} / {maxCredits} credits
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all ${
                  totalCredits > maxCredits
                    ? 'bg-red-600'
                    : totalCredits >= maxCredits * 0.8
                    ? 'bg-yellow-500'
                    : 'bg-blue-600'
                }`}
                style={{ width: `${Math.min((totalCredits / maxCredits) * 100, 100)}%` }}
              ></div>
            </div>
            {totalCredits > maxCredits && (
              <p className="text-sm text-red-600 mt-2">
                ⚠ Warning: You have exceeded the maximum credit limit
              </p>
            )}
          </div>

          {/* Enrolled Courses */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg text-gray-900">Currently Enrolled Courses</h3>
            </div>
            {selectedCourses.length === 0 ? (
              <div className="p-12 text-center">
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h4 className="text-lg text-gray-900 mb-2">No courses selected yet</h4>
                <p className="text-gray-600 mb-6">
                  Start building your schedule by browsing available courses
                </p>
                <a
                  href="/student/courses"
                  className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Browse Courses
                </a>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {selectedCourses.map((course) => (
                  <div key={course.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-4">
                        <div
                          className="w-1 h-16 rounded-full"
                          style={{ backgroundColor: course.color }}
                        ></div>
                        <div>
                          <h4 className="text-lg text-gray-900 mb-1">{course.name}</h4>
                          <p className="text-sm text-gray-600 mb-2">{course.instructor}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <span>
                              {course.day} {course.startTime} - {course.endTime}
                            </span>
                            <span>{course.credits} credits</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-3 py-1 bg-green-50 text-green-700 text-sm rounded-full">
                          Enrolled
                        </span>
                        <button
                          className="p-2 bg-red-50 text-red-700 text-sm rounded-full hover:bg-red-600 hover:text-white transition-colors"
                          onClick={() => {
                            removeCourse(course.id);
                            toast.success(`Removed ${course.name} from your schedule`);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}