import { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Search, Filter, Users, Clock, Award, CheckCircle, AlertCircle } from 'lucide-react';
import { useCourses } from '../context/CourseContext';
import { ConflictModal } from './ConflictModal';
import { Course } from '../types';
import { toast } from 'sonner';

export function CourseListing() {
  const { courses, selectedCourses, addCourse, removeCourse, replaceCourse } = useCourses();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDay, setSelectedDay] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'name' | 'credits' | 'enrollment'>('name');
  const [conflictModalOpen, setConflictModalOpen] = useState(false);
  const [pendingCourse, setPendingCourse] = useState<Course | null>(null);
  const [conflictingCourse, setConflictingCourse] = useState<Course | null>(null);
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');

  const days = ['All', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDay = selectedDay === 'All' || course.day === selectedDay;
    return matchesSearch && matchesDay;
  }).sort((a, b) => {
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'credits') return b.credits - a.credits;
    if (sortBy === 'enrollment') {
      const aAvailable = a.maxCapacity - a.enrolled;
      const bAvailable = b.maxCapacity - b.enrolled;
      return bAvailable - aAvailable;
    }
    return 0;
  });

  const handleSelectCourse = (course: Course) => {
    const isSelected = selectedCourses.some((c) => c.id === course.id);
    
    if (isSelected) {
      removeCourse(course.id);
      toast.success('Course removed from your schedule');
      return;
    }

    const totalCredits = selectedCourses.reduce((sum, c) => sum + c.credits, 0);
    if (totalCredits + course.credits > 20) {
      toast.error('Maximum credit limit (20) exceeded!');
      return;
    }

    const result = addCourse(course);
    if (result.success) {
      toast.success(`${course.name} added to your schedule!`);
    } else if (result.conflict) {
      setPendingCourse(course);
      setConflictingCourse(result.conflict);
      setConflictModalOpen(true);
    }
  };

  const handleReplace = () => {
    if (pendingCourse && conflictingCourse) {
      replaceCourse(conflictingCourse.id, pendingCourse);
      toast.success(`Replaced ${conflictingCourse.name} with ${pendingCourse.name}`);
      setConflictModalOpen(false);
      setPendingCourse(null);
      setConflictingCourse(null);
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" />

      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <h1 className="text-3xl text-gray-900 mb-2">Browse Courses</h1>
          <p className="text-gray-600">Explore and select courses for the semester</p>
        </div>

        {/* Filters & Search */}
        <div className="p-8">
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by course name or instructor..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Day Filter */}
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-gray-400" />
                <select
                  value={selectedDay}
                  onChange={(e) => setSelectedDay(e.target.value)}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {days.map((day) => (
                    <option key={day} value={day}>
                      {day}
                    </option>
                  ))}
                </select>
              </div>

              {/* Sort By */}
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-gray-400" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'name' | 'credits' | 'enrollment')}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="name">Name</option>
                  <option value="credits">Credits</option>
                  <option value="enrollment">Enrollment</option>
                </select>
              </div>

              {/* View Toggle */}
              <div className="flex gap-2 border border-gray-300 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('card')}
                  className={`px-4 py-2 rounded ${
                    viewMode === 'card'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  Cards
                </button>
                <button
                  onClick={() => setViewMode('table')}
                  className={`px-4 py-2 rounded ${
                    viewMode === 'table'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  Table
                </button>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="mb-4">
            <p className="text-sm text-gray-600">
              Showing {filteredCourses.length} course{filteredCourses.length !== 1 ? 's' : ''}
            </p>
          </div>

          {/* Card View */}
          {viewMode === 'card' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredCourses.map((course) => {
                const isSelected = selectedCourses.some((c) => c.id === course.id);
                const availableSeats = course.maxCapacity - course.enrolled;
                const isAlmostFull = availableSeats < 5;

                return (
                  <div
                    key={course.id}
                    className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="text-lg text-gray-900 pr-2">{course.name}</h3>
                      {isSelected && (
                        <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                      )}
                    </div>

                    <p className="text-sm text-gray-600 mb-4">{course.instructor}</p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span>
                          {course.day} {course.startTime} - {course.endTime}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Award className="w-4 h-4 text-gray-400" />
                        <span>{course.credits} Credits</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span>
                          {course.enrolled}/{course.maxCapacity} enrolled
                        </span>
                      </div>
                    </div>

                    {isAlmostFull && !isSelected && (
                      <div className="flex items-center gap-2 mb-4 p-2 bg-yellow-50 rounded-lg">
                        <AlertCircle className="w-4 h-4 text-yellow-600" />
                        <span className="text-xs text-yellow-700">Only {availableSeats} seats left!</span>
                      </div>
                    )}

                    <button
                      onClick={() => handleSelectCourse(course)}
                      disabled={!isSelected && availableSeats === 0}
                      className={`w-full py-2 px-4 rounded-lg transition-colors ${
                        isSelected
                          ? 'bg-red-50 text-red-600 hover:bg-red-100'
                          : availableSeats === 0
                          ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      {isSelected ? 'Remove Course' : availableSeats === 0 ? 'Course Full' : 'Select Course'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Table View */}
          {viewMode === 'table' && (
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Course Name</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Instructor</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Schedule</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Credits</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Enrollment</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredCourses.map((course) => {
                    const isSelected = selectedCourses.some((c) => c.id === course.id);
                    const availableSeats = course.maxCapacity - course.enrolled;

                    return (
                      <tr key={course.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            {isSelected && <CheckCircle className="w-4 h-4 text-green-600" />}
                            <span className="text-sm text-gray-900">{course.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{course.instructor}</td>
                        <td className="px-6 py-4 text-sm text-gray-700">
                          {course.day} {course.startTime}-{course.endTime}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{course.credits}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`text-sm ${
                              availableSeats < 5 ? 'text-yellow-700' : 'text-gray-700'
                            }`}
                          >
                            {course.enrolled}/{course.maxCapacity}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleSelectCourse(course)}
                            disabled={!isSelected && availableSeats === 0}
                            className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                              isSelected
                                ? 'bg-red-50 text-red-600 hover:bg-red-100'
                                : availableSeats === 0
                                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                : 'bg-blue-600 text-white hover:bg-blue-700'
                            }`}
                          >
                            {isSelected ? 'Remove' : availableSeats === 0 ? 'Full' : 'Select'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Conflict Modal */}
      {pendingCourse && conflictingCourse && (
        <ConflictModal
          isOpen={conflictModalOpen}
          onClose={() => {
            setConflictModalOpen(false);
            setPendingCourse(null);
            setConflictingCourse(null);
          }}
          newCourse={pendingCourse}
          conflictingCourse={conflictingCourse}
          onReplace={handleReplace}
        />
      )}
    </div>
  );
}