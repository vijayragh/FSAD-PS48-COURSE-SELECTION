import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Course, SelectedCourse, UserRole } from '../types';
import { mockCourses } from '../data/mockCourses';

interface CourseContextType {
  courses: Course[];
  selectedCourses: SelectedCourse[];
  userRole: UserRole | null;
  addCourse: (course: Course) => { success: boolean; conflict?: Course };
  removeCourse: (courseId: string) => void;
  replaceCourse: (oldCourseId: string, newCourse: Course) => void;
  setUserRole: (role: UserRole) => void;
  addNewCourse: (course: Omit<Course, 'id' | 'enrolled'>) => void;
  updateCourse: (id: string, course: Omit<Course, 'id' | 'enrolled'>) => void;
  deleteCourse: (id: string) => void;
}

const CourseContext = createContext<CourseContextType | undefined>(undefined);

const courseColors = [
  '#3b82f6', // blue
  '#8b5cf6', // purple
  '#10b981', // green
  '#f59e0b', // amber
  '#ef4444', // red
  '#06b6d4', // cyan
  '#ec4899', // pink
  '#14b8a6', // teal
];

export function CourseProvider({ children }: { children: ReactNode }) {
  const [courses, setCourses] = useState<Course[]>(mockCourses);
  const [selectedCourses, setSelectedCourses] = useState<SelectedCourse[]>([]);
  const [userRole, setUserRole] = useState<UserRole | null>(null);

  const checkConflict = (newCourse: Course): Course | null => {
    for (const selected of selectedCourses) {
      if (selected.day === newCourse.day) {
        const selectedStart = timeToMinutes(selected.startTime);
        const selectedEnd = timeToMinutes(selected.endTime);
        const newStart = timeToMinutes(newCourse.startTime);
        const newEnd = timeToMinutes(newCourse.endTime);

        if (
          (newStart >= selectedStart && newStart < selectedEnd) ||
          (newEnd > selectedStart && newEnd <= selectedEnd) ||
          (newStart <= selectedStart && newEnd >= selectedEnd)
        ) {
          return selected;
        }
      }
    }
    return null;
  };

  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const addCourse = (course: Course) => {
    const conflict = checkConflict(course);
    if (conflict) {
      return { success: false, conflict };
    }

    const colorIndex = selectedCourses.length % courseColors.length;
    setSelectedCourses([
      ...selectedCourses,
      { ...course, color: courseColors[colorIndex] },
    ]);
    return { success: true };
  };

  const removeCourse = (courseId: string) => {
    setSelectedCourses(selectedCourses.filter((c) => c.id !== courseId));
  };

  const replaceCourse = (oldCourseId: string, newCourse: Course) => {
    const filtered = selectedCourses.filter((c) => c.id !== oldCourseId);
    const colorIndex = filtered.length % courseColors.length;
    setSelectedCourses([...filtered, { ...newCourse, color: courseColors[colorIndex] }]);
  };

  const addNewCourse = (courseData: Omit<Course, 'id' | 'enrolled'>) => {
    const newCourse: Course = {
      ...courseData,
      id: Date.now().toString(),
      enrolled: 0,
    };
    setCourses([...courses, newCourse]);
  };

  const updateCourse = (id: string, courseData: Omit<Course, 'id' | 'enrolled'>) => {
    setCourses(
      courses.map((c) => (c.id === id ? { ...courseData, id, enrolled: c.enrolled } : c))
    );
  };

  const deleteCourse = (id: string) => {
    setCourses(courses.filter((c) => c.id !== id));
    setSelectedCourses(selectedCourses.filter((c) => c.id !== id));
  };

  return (
    <CourseContext.Provider
      value={{
        courses,
        selectedCourses,
        userRole,
        addCourse,
        removeCourse,
        replaceCourse,
        setUserRole,
        addNewCourse,
        updateCourse,
        deleteCourse,
      }}
    >
      {children}
    </CourseContext.Provider>
  );
}

export function useCourses() {
  const context = useContext(CourseContext);
  if (!context) {
    throw new Error('useCourses must be used within CourseProvider');
  }
  return context;
}
