export interface Course {
  id: string;
  name: string;
  instructor: string;
  day: string;
  startTime: string;
  endTime: string;
  credits: number;
  maxCapacity: number;
  enrolled: number;
}

export interface SelectedCourse extends Course {
  color: string;
}

export type UserRole = 'student' | 'admin';
