import { RouterProvider } from 'react-router';
import { router } from './routes';
import { CourseProvider } from './context/CourseContext';
import { Toaster } from 'sonner';

export default function App() {
  return (
    <CourseProvider>
      <RouterProvider router={router} />
      <Toaster position="top-right" />
    </CourseProvider>
  );
}