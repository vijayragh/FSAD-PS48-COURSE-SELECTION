import { Sidebar } from './Sidebar';
import { useCourses } from '../context/CourseContext';
import { Calendar, Download, Printer } from 'lucide-react';

export function Timetable() {
  const { selectedCourses } = useCourses();

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeSlots = [
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
  ];

  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const getCourseForSlot = (day: string, timeSlot: string) => {
    const slotMinutes = timeToMinutes(timeSlot);
    const nextSlotMinutes = slotMinutes + 60;

    return selectedCourses.find((course) => {
      if (course.day !== day) return false;

      const courseStart = timeToMinutes(course.startTime);
      const courseEnd = timeToMinutes(course.endTime);

      return courseStart < nextSlotMinutes && courseEnd > slotMinutes;
    });
  };

  const getCourseDuration = (course: any, timeSlot: string): number => {
    const slotMinutes = timeToMinutes(timeSlot);
    const courseStart = timeToMinutes(course.startTime);
    const courseEnd = timeToMinutes(course.endTime);
    
    const durationMinutes = courseEnd - courseStart;
    return Math.ceil(durationMinutes / 60);
  };

  const isFirstSlotOfCourse = (course: any, timeSlot: string): boolean => {
    const slotMinutes = timeToMinutes(timeSlot);
    const courseStart = timeToMinutes(course.startTime);
    return slotMinutes === courseStart;
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="student" />

      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl text-gray-900 mb-2">My Timetable</h1>
              <p className="text-gray-600">Weekly schedule overview</p>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                <Download className="w-4 h-4" />
                Export
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-8">
          {selectedCourses.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl text-gray-900 mb-2">No courses in your schedule yet</h3>
              <p className="text-gray-600 mb-6">
                Add courses to see your weekly timetable
              </p>
              <a
                href="/student/courses"
                className="inline-block bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors"
              >
                Browse Courses
              </a>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              {/* Timetable Grid */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-4 py-4 text-left text-sm text-gray-700 w-24 sticky left-0 bg-gray-50">
                        Time
                      </th>
                      {days.map((day) => (
                        <th
                          key={day}
                          className="px-4 py-4 text-center text-sm text-gray-700 min-w-[180px]"
                        >
                          {day}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {timeSlots.map((timeSlot, timeIndex) => (
                      <tr key={timeSlot} className="border-b border-gray-200">
                        <td className="px-4 py-4 text-sm text-gray-600 sticky left-0 bg-white border-r border-gray-200">
                          <div className="text-center">
                            <div>{timeSlot}</div>
                            <div className="text-xs text-gray-400">
                              {timeSlots[timeIndex + 1] || '18:00'}
                            </div>
                          </div>
                        </td>
                        {days.map((day) => {
                          const course = getCourseForSlot(day, timeSlot);
                          const isFirstSlot = course ? isFirstSlotOfCourse(course, timeSlot) : false;

                          if (course && !isFirstSlot) {
                            return <td key={day} className="border-r border-gray-200"></td>;
                          }

                          if (course && isFirstSlot) {
                            const duration = getCourseDuration(course, timeSlot);
                            return (
                              <td
                                key={day}
                                rowSpan={duration}
                                className="border-r border-gray-200 p-2 align-top"
                              >
                                <div
                                  className="h-full p-3 rounded-lg text-white shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                                  style={{ backgroundColor: course.color }}
                                >
                                  <h4 className="text-sm mb-1 leading-tight">{course.name}</h4>
                                  <p className="text-xs opacity-90 mb-1">
                                    {course.instructor}
                                  </p>
                                  <p className="text-xs opacity-90">
                                    {course.startTime} - {course.endTime}
                                  </p>
                                  <div className="mt-2 inline-block bg-white/20 rounded px-2 py-0.5 text-xs">
                                    {course.credits} credits
                                  </div>
                                </div>
                              </td>
                            );
                          }

                          return (
                            <td
                              key={day}
                              className="border-r border-gray-200 p-2 hover:bg-gray-50 transition-colors"
                            >
                              <div className="h-20"></div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Legend */}
              <div className="p-6 border-t border-gray-200 bg-gray-50">
                <h4 className="text-sm text-gray-700 mb-3">Course Legend:</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {selectedCourses.map((course) => (
                    <div key={course.id} className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: course.color }}
                      ></div>
                      <span className="text-sm text-gray-700">{course.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}