import { Sidebar } from './Sidebar';
import { BookOpen, Users, TrendingUp, Plus, Edit2, Trash2 } from 'lucide-react';
import { useCourses } from '../context/CourseContext';
import { Link } from 'react-router';
import { toast } from 'sonner';

export function AdminDashboard() {
  const { courses, deleteCourse } = useCourses();

  const totalCourses = courses.length;
  const totalEnrolled = courses.reduce((sum, course) => sum + course.enrolled, 0);
  const totalCapacity = courses.reduce((sum, course) => sum + course.maxCapacity, 0);
  const averageEnrollment = totalCourses > 0 ? Math.round(totalEnrolled / totalCourses) : 0;

  const stats = [
    {
      label: 'Total Courses',
      value: totalCourses,
      icon: BookOpen,
      color: 'bg-purple-50 text-purple-600',
    },
    {
      label: 'Total Students Enrolled',
      value: totalEnrolled,
      icon: Users,
      color: 'bg-green-50 text-green-600',
    },
    {
      label: 'Total Capacity',
      value: totalCapacity,
      icon: TrendingUp,
      color: 'bg-purple-50 text-purple-600',
    },
    {
      label: 'Avg. Enrollment',
      value: averageEnrollment,
      icon: TrendingUp,
      color: 'bg-orange-50 text-orange-600',
    },
  ];

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteCourse(id);
      toast.success('Course deleted successfully');
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" />

      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl text-gray-900 mb-2">Admin Dashboard</h1>
              <p className="text-gray-600">Manage courses and enrollments</p>
            </div>
            <Link
              to="/admin/course/new"
              className="flex items-center gap-2 bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add New Course
            </Link>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-lg ${stat.color}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                  <h3 className="text-2xl text-gray-900 mb-1">{stat.value}</h3>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Course Management Table */}
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg text-gray-900">Course Management</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Course Name</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Instructor</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Schedule</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Credits</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Enrollment</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Status</th>
                    <th className="px-6 py-4 text-left text-sm text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {courses.map((course) => {
                    const enrollmentPercentage = Math.round(
                      (course.enrolled / course.maxCapacity) * 100
                    );
                    const isFull = course.enrolled >= course.maxCapacity;
                    const isAlmostFull = enrollmentPercentage >= 80;

                    return (
                      <tr key={course.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <span className="text-sm text-gray-900">{course.name}</span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{course.instructor}</td>
                        <td className="px-6 py-4 text-sm text-gray-700">
                          {course.day} {course.startTime}-{course.endTime}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{course.credits}</td>
                        <td className="px-6 py-4">
                          <div className="space-y-1">
                            <div className="text-sm text-gray-700">
                              {course.enrolled}/{course.maxCapacity}
                            </div>
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  isFull
                                    ? 'bg-red-600'
                                    : isAlmostFull
                                    ? 'bg-yellow-500'
                                    : 'bg-green-600'
                                }`}
                                style={{ width: `${Math.min(enrollmentPercentage, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {isFull ? (
                            <span className="px-3 py-1 bg-red-50 text-red-700 text-xs rounded-full">
                              Full
                            </span>
                          ) : isAlmostFull ? (
                            <span className="px-3 py-1 bg-yellow-50 text-yellow-700 text-xs rounded-full">
                              Almost Full
                            </span>
                          ) : (
                            <span className="px-3 py-1 bg-green-50 text-green-700 text-xs rounded-full">
                              Available
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Link
                              to={`/admin/course/edit/${course.id}`}
                              className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                              title="Edit"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Link>
                            <button
                              onClick={() => handleDelete(course.id, course.name)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}