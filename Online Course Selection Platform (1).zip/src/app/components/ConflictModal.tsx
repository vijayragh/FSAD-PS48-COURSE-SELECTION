import { AlertTriangle, X } from 'lucide-react';
import { Course } from '../types';

interface ConflictModalProps {
  isOpen: boolean;
  onClose: () => void;
  newCourse: Course;
  conflictingCourse: Course;
  onReplace: () => void;
}

export function ConflictModal({
  isOpen,
  onClose,
  newCourse,
  conflictingCourse,
  onReplace,
}: ConflictModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-xl text-gray-900">Schedule Conflict Detected</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-gray-700">
            The course you're trying to add overlaps with an existing course in your schedule.
          </p>

          {/* New Course */}
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-xl">
            <p className="text-sm text-purple-900 mb-2">Course you want to add:</p>
            <h3 className="text-lg text-purple-900 mb-1">{newCourse.name}</h3>
            <p className="text-sm text-purple-700">
              {newCourse.day} {newCourse.startTime} - {newCourse.endTime}
            </p>
          </div>

          {/* Conflicting Course */}
          <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-sm text-red-900 mb-2">Conflicts with:</p>
            <h3 className="text-lg text-red-900 mb-1">{conflictingCourse.name}</h3>
            <p className="text-sm text-red-700">
              {conflictingCourse.day} {conflictingCourse.startTime} -{' '}
              {conflictingCourse.endTime}
            </p>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <p className="text-sm text-yellow-900">
              💡 You can replace the conflicting course or cancel and choose a different time
              slot.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 p-6 bg-gray-50 rounded-b-2xl">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onReplace}
            className="flex-1 px-4 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
          >
            Replace Existing Course
          </button>
        </div>
      </div>
    </div>
  );
}