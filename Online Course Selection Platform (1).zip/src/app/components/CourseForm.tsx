import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Sidebar } from './Sidebar';
import { Save, X, ArrowLeft } from 'lucide-react';
import { useCourses } from '../context/CourseContext';
import { toast } from 'sonner';

export function CourseForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { courses, addNewCourse, updateCourse } = useCourses();
  
  const isEditing = Boolean(id);
  const existingCourse = isEditing ? courses.find((c) => c.id === id) : null;

  const [formData, setFormData] = useState({
    name: existingCourse?.name || '',
    instructor: existingCourse?.instructor || '',
    day: existingCourse?.day || 'Monday',
    startTime: existingCourse?.startTime || '09:00',
    endTime: existingCourse?.endTime || '10:00',
    credits: existingCourse?.credits || 3,
    maxCapacity: existingCourse?.maxCapacity || 30,
  });

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeOptions = [
    '08:00', '09:00', '10:00', '11:00', '12:00', '13:00',
    '14:00', '15:00', '16:00', '17:00', '18:00'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'credits' || name === 'maxCapacity' ? parseInt(value) : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate end time is after start time
    const startMinutes = timeToMinutes(formData.startTime);
    const endMinutes = timeToMinutes(formData.endTime);
    
    if (endMinutes <= startMinutes) {
      toast.error('End time must be after start time');
      return;
    }

    if (isEditing && id) {
      updateCourse(id, formData);
      toast.success('Course updated successfully');
    } else {
      addNewCourse(formData);
      toast.success('Course added successfully');
    }
    
    navigate('/admin/dashboard');
  };

  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="admin" />

      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/admin/dashboard')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-3xl text-gray-900 mb-2">
                {isEditing ? 'Edit Course' : 'Add New Course'}
              </h1>
              <p className="text-gray-600">
                {isEditing ? 'Update course information' : 'Create a new course in the system'}
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="p-8">
          <div className="max-w-3xl mx-auto">
            <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-gray-200 p-8">
              <div className="space-y-6">
                {/* Course Name */}
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Course Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g., Data Structures and Algorithms"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    required
                  />
                </div>

                {/* Instructor */}
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Instructor Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="instructor"
                    value={formData.instructor}
                    onChange={handleChange}
                    placeholder="e.g., Dr. Sarah Johnson"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    required
                  />
                </div>

                {/* Day and Time Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Day */}
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Day <span className="text-red-600">*</span>
                    </label>
                    <select
                      name="day"
                      value={formData.day}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    >
                      {days.map((day) => (
                        <option key={day} value={day}>
                          {day}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Start Time */}
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Start Time <span className="text-red-600">*</span>
                    </label>
                    <select
                      name="startTime"
                      value={formData.startTime}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    >
                      {timeOptions.map((time) => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* End Time */}
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      End Time <span className="text-red-600">*</span>
                    </label>
                    <select
                      name="endTime"
                      value={formData.endTime}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    >
                      {timeOptions.map((time) => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Credits and Capacity Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Credits */}
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Credits <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="number"
                      name="credits"
                      value={formData.credits}
                      onChange={handleChange}
                      min="1"
                      max="6"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">Typically 3-4 credits</p>
                  </div>

                  {/* Maximum Capacity */}
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Maximum Capacity <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="number"
                      name="maxCapacity"
                      value={formData.maxCapacity}
                      onChange={handleChange}
                      min="10"
                      max="100"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">Maximum number of students</p>
                  </div>
                </div>

                {/* Info Box */}
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <p className="text-sm text-purple-900">
                    ℹ️ All fields marked with <span className="text-red-600">*</span> are required. 
                    Make sure the schedule doesn't conflict with existing courses for the instructor.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 mt-8 pt-6 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => navigate('/admin/dashboard')}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <X className="w-5 h-5" />
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Save className="w-5 h-5" />
                  {isEditing ? 'Update Course' : 'Create Course'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}