# 🧭 Navigation Guide - Course Selection Platform

## Quick Start Guide

### 🚀 Getting Started

1. **Open the Application**: You'll land on the Login Page
2. **Choose Your Role**: Click either "Student" or "Admin"
3. **Login**: Enter any email/password (demo mode - authentication is visual only)
4. **Explore**: Navigate through the platform using the sidebar

---

## 🎓 Student Navigation

### From Login Page → Student Portal

After selecting "Student" role and logging in:

```
LOGIN PAGE (/)
    ↓
STUDENT DASHBOARD (/student/dashboard)
    │
    ├─→ Browse Courses (/student/courses)
    │       ├─ Search courses
    │       ├─ Filter by day
    │       ├─ Sort by name/credits/enrollment
    │       ├─ Toggle Card/Table view
    │       └─ Select/Remove courses
    │           └─ If conflict → Conflict Modal appears
    │
    ├─→ My Timetable (/student/timetable)
    │       ├─ View weekly schedule grid
    │       ├─ See color-coded courses
    │       └─ Export/Print options
    │
    └─→ Settings (button available, page TBD)
```

### Student Sidebar Links:
- **Dashboard** 📊 - Overview of enrolled courses and stats
- **Browse Courses** 📚 - Course catalog with search/filter
- **My Timetable** 📅 - Weekly schedule visualization
- **Settings** ⚙️ - (UI ready)
- **Logout** 🚪 - Returns to login page

---

## 👨‍💼 Admin Navigation

### From Login Page → Admin Portal

After selecting "Admin" role and logging in:

```
LOGIN PAGE (/)
    ↓
ADMIN DASHBOARD (/admin/dashboard)
    │
    ├─→ Add Course (/admin/course/new)
    │       ├─ Fill course details form
    │       ├─ Validate inputs
    │       └─ Save → Return to dashboard
    │
    ├─→ Edit Course (/admin/course/edit/:id)
    │       ├─ Pre-filled form with existing data
    │       ├─ Update fields
    │       └─ Save → Return to dashboard
    │
    └─→ Delete Course (from dashboard table)
            └─ Confirmation dialog → Delete
```

### Admin Sidebar Links:
- **Dashboard** 📊 - System stats and course management table
- **Add Course** ➕ - Create new course form
- **Settings** ⚙️ - (UI ready)
- **Logout** 🚪 - Returns to login page

---

## 📍 Complete Route Map

| Route | Component | Access | Description |
|-------|-----------|--------|-------------|
| `/` | LoginPage | Public | Login with role selection |
| `/student/dashboard` | StudentDashboard | Student | Personal stats and enrolled courses |
| `/student/courses` | CourseListing | Student | Browse and select courses |
| `/student/timetable` | Timetable | Student | Weekly schedule view |
| `/admin/dashboard` | AdminDashboard | Admin | System overview and course table |
| `/admin/course/new` | CourseForm | Admin | Add new course form |
| `/admin/course/edit/:id` | CourseForm | Admin | Edit existing course form |
| `*` (404) | NotFound | All | Page not found error |

---

## 🎯 User Flows

### Student: Selecting a Course

1. **Login** as Student
2. Click **"Browse Courses"** in sidebar
3. Use **Search bar** to find course (e.g., "Data Structures")
4. Or use **Filter** to select a day (e.g., "Monday")
5. Click **"Select Course"** button
6. **Two scenarios**:
   
   **A. No Conflict:**
   - ✅ Green toast: "Data Structures added to your schedule!"
   - Course shows green checkmark
   - Button changes to "Remove Course"
   
   **B. Conflict Detected:**
   - ⚠️ Modal appears: "Schedule Conflict Detected"
   - Shows new course (blue) vs. existing course (red)
   - Options:
     - **Cancel** → Modal closes, nothing changes
     - **Replace Existing Course** → Old course removed, new course added

7. Click **"My Timetable"** to see visual schedule
8. Return to **Dashboard** to see updated stats

---

### Admin: Adding a New Course

1. **Login** as Admin
2. Dashboard shows current system stats
3. Click **"Add New Course"** (blue button, top-right)
4. Fill in the form:
   - Course Name: "Quantum Computing"
   - Instructor: "Dr. Albert Einstein"
   - Day: "Wednesday"
   - Start Time: "11:00"
   - End Time: "13:00"
   - Credits: 4
   - Maximum Capacity: 30
5. Click **"Create Course"**
6. ✅ Toast: "Course added successfully"
7. Redirected to Dashboard
8. New course appears in table

---

### Admin: Editing a Course

1. From Admin Dashboard
2. Find course in table
3. Click **Edit icon** (blue pencil)
4. Form opens with **pre-filled data**
5. Modify fields (e.g., change capacity from 30 to 40)
6. Click **"Update Course"**
7. ✅ Toast: "Course updated successfully"
8. Return to dashboard with updated data

---

### Admin: Deleting a Course

1. From Admin Dashboard
2. Find course in table
3. Click **Delete icon** (red trash)
4. Confirmation dialog: "Are you sure you want to delete..."
5. Click **OK**
6. ✅ Toast: "Course deleted successfully"
7. Course removed from table

---

## 🎨 Visual Navigation Cues

### Sidebar Indicators:
- **Active Route**: Blue background (#EFF6FF) with blue text (#2563EB)
- **Inactive Route**: Gray text (#374151) with white background
- **Hover State**: Light gray background (#F9FAFB)

### Status Indicators:
- **Green Checkmark** ✅ = Course selected
- **Yellow Warning** ⚠️ = Almost full (<5 seats)
- **Red X** ❌ = Course full
- **Blue Info** ℹ️ = General information

### Button States:
- **Primary Action**: Blue (#2563EB) - Select, Save, Create
- **Destructive Action**: Red (#DC2626) - Delete, Remove, Replace
- **Secondary Action**: Gray border - Cancel, Go Back
- **Disabled State**: Gray (#D1D5DB) - Course Full, Max Credits

---

## 🔄 Navigation Patterns

### Breadcrumb Navigation:
Each page shows your current location:
- **Student**: Dashboard → Courses → Timetable
- **Admin**: Dashboard → Add/Edit Course

### Back Navigation:
- **Sidebar Links**: Always available for quick navigation
- **Back Button**: Available in forms (arrow-left icon)
- **Logout**: Returns to login page from any screen

### Deep Linking:
All routes support direct URL access:
- Bookmark `/student/timetable` to go directly to schedule
- Share `/admin/course/new` to go directly to add course form

---

## 📱 Responsive Behavior

### Desktop (1024px+):
- Full sidebar visible
- Multi-column layouts (cards grid, stats grid)
- Expanded timetable

### Tablet (768px-1023px):
- Sidebar remains visible
- Reduced columns (2 instead of 3-4)
- Condensed timetable

### Mobile (<768px):
- Sidebar may collapse (UI ready for mobile menu)
- Single column layouts
- Stacked cards
- Horizontal scroll for timetable

---

## 🚨 Error Handling

### 404 - Page Not Found:
If you navigate to non-existent route (e.g., `/random-page`):
- Shows "404 Page Not Found" screen
- **"Go Back"** button → Returns to previous page
- **"Home"** button → Returns to login page

### Invalid Actions:
- **Credit Limit Exceeded**: Toast error + selection blocked
- **Course Full**: Button disabled, shows "Course Full"
- **Schedule Conflict**: Modal appears with options

---

## 💡 Pro Tips

### For Students:
1. Use **Search** to quickly find specific courses
2. Use **Day Filter** to build schedule around specific days
3. Check **Timetable** frequently to visualize schedule
4. Monitor **Credit Progress** bar in Dashboard
5. Use **Card View** for browsing, **Table View** for comparing

### For Admins:
1. Monitor **Enrollment Progress Bars** to identify popular courses
2. Use **Status Badges** to quickly see course availability
3. Edit courses to adjust capacity when needed
4. Delete outdated courses to keep catalog clean
5. Check **Average Enrollment** stat to gauge overall demand

---

## 🎯 Testing Conflict Detection

To test the smart conflict detection:

1. Login as **Student**
2. Go to **Browse Courses**
3. Select "**Data Structures**" (Monday 10:00-11:00)
4. Try to select "**Artificial Intelligence**" (Monday 10:00-12:00)
5. **Conflict Modal** appears! 🎉
6. Try "Replace" to swap courses
7. Or try "Cancel" to keep original selection

---

## ✨ Hidden Features

1. **Toast Notifications**: Every action shows feedback
2. **Empty States**: Helpful prompts when no data
3. **Color Legend**: Timetable shows color coding for courses
4. **Enrollment Percentage**: Visual bars in admin table
5. **Sort Persistence**: Selections maintain while browsing

---

**Happy Navigating! 🎓📚**
